//projekt na zaliczenie z przedmiotu "Przetwarzanie danych w JS"
// autor: Magdalena Mroziuk magdamroziuk@wp.pl
// projekt zainicjowany $ npm init
// $ npm install command-line-args --save
// $ npm add --save underscore
// dane GEOJSON ze strony https://github.com/ppatrzyk/polska-geojson w wersji min

//dołącz underscore
const _ = require('underscore');

// wczytaj dane z pliku GEOJSON
const fs = require('fs');
const readData = fs.readFileSync('powiaty-min.geojson'); //wczytuje plik
const listaPowiaty = JSON.parse(readData); //przetwarza na obiekt
const powiaty = listaPowiaty.features; //tablica z danymi powiatów

//parametry wywołania
const myArgs = process.argv.slice(2);

if (myArgs[0] !== undefined) {
    myArgs[0] = myArgs[0].toLowerCase();
}

switch (myArgs[0]) {

    case '-l':
        //wyświetlanie listy wszystkich powiatów w kolejności alfabetycznej
        console.log('');
        console.log('Lista powiatów w kolejności alfabetycznej:');
        console.log('');
        var alfabetycznie = _.pluck(powiaty, 'properties'); //tablica obiektów 'properties' z GEOJSON
        //tablica nazw powiatów
        alfabetycznie = _.map(alfabetycznie, function(e) { //mapuje na kolekcję tablic dwuelementowych w postaci wartości Id i nazwy powiatu
            return _.keys(_.invert(e));
        });
        alfabetycznie = _.map(alfabetycznie, function(e) { //obcina z nazwy znaki "powiat "
            e[0] = e[0];
            e[1] = e[1].slice(7);
            return e;
        });
        alfabetycznie.sort((a, b) => a[1].localeCompare(b[1])); //sortuje tablicę po polu z nazwą wg polskich reguł
        _.each(alfabetycznie, function(e) { console.log(e[0], e[1]) }); //wydruk alfabetycznej listy powiatów wraz z ich Id
        console.log('');
        break;

    case '-a':
        console.log('');
        if ((myArgs[1] === undefined) || (myArgs[2] === undefined) || (myArgs[1] > myArgs[2])) { //sprawdza poprawność argumentów zakresu
            console.log('');
            console.log("Podaj prawidłowy zakres!");
            console.log('');
            break;
        } else { //poprawny zakres
            console.log('');
            console.log('Powierzchnia powiatów z danego zakresu od ' + myArgs[1] + " do " + myArgs[2]);
            console.log('');

            var zakres = _.first(powiaty, [myArgs[2]]);
            zakres = _.rest(zakres, [myArgs[1] - 1]); //redukuje kolekcję "powiaty" do zakresu


            function pole(tablica) { //liczy pole najprostszego Polygonu (bez wycięć) dla tablicy z parami współrzędnych
                // próbowałam to zrobić metodą -.reduce, ale nie umiem tego zaimplementować z działaniem na podwójnych indeksach
                let max = _.size(tablica);
                let suma = 0;
                for (let i = 0; i < max - 1; i++) {
                    suma += tablica[i][0] * tablica[i + 1][1];
                    suma -= tablica[i][1] * tablica[i + 1][0];
                }
                let pole = Math.abs(suma) / 2;
                return pole;
            }

            function polePolygon(tablica) { //liczy pole Polygonu (z jednym wycięciem i bez) korzystając z funkcji pole()
                if (_.size(tablica) === 1) { return pole(tablica[0]); } else { return pole(tablica[0]) - pole(tablica[1]); }
            }

            function poleMultiPolygon(tablica) { //liczy pole MultiPolygonu korzystając z funkcji polePolygon() na każdej składowej
                let pole = 0;
                pole = _.reduce(tablica, function(memo, num) {
                    return memo + polePolygon(num);
                }, 0);
                return pole;
            }

            function polePowiatu(x) { //liczy pole powiatu w zależności, czy jest to Polygon czy MultiPolygon, argumentem jest Id powiatu
                if (powiaty[x].geometry.type === "Polygon") {
                    return polePolygon(powiaty[x].geometry.coordinates);
                } else { return poleMultiPolygon(powiaty[x].geometry.coordinates); }
            }

            _.each(zakres, function(e) { //wydruk na konsolę zakresu z polem powierzchni
                console.log(e.properties.id, e.properties.nazwa, ' powierzchnia: ', polePowiatu(e.id));
            });
            console.log('');
            break;
        };
    default: //menu i pomoc do skryptu
        console.log('');
        console.log('');
        console.log('Witaj w skrypcie "Powiaty w Polsce"');
        console.log('Wywołaj skrypt "powiaty1.js" z jedną z poniższych opcji:');
        console.log('"-L"  - Lista wszystkich powiatów w Polsce');
        console.log('"-A [Id_początkowe] [Id_końcowe]"  - Wyświetla powierzchnię powiatów z zakresu od Id_początkowe do Id_końcowe');
        console.log('Id to liczba całkowita z zakresu od 1 do 380');
        console.log('Liczby oddziel spacją');
        console.log('');
}